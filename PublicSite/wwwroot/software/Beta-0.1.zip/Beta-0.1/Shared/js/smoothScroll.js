
var scrollToElemnt = function( element ){
    $('html, body').animate( { scrollTop: $( element ).offset().top }, 500 );
}